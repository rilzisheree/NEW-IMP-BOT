# Valor System — Setup Instructions

Drop these files into your existing NEW-IMP-BOT and you're done.

---

## 1. Copy the files

```
valor-system/src/models/       →  src/models/
valor-system/src/commands/valor/  →  src/commands/valor/
valor-system/src/lib/valorPerms.js  →  src/lib/valorPerms.js
```

---

## 2. Add OWNER_IDS to your .env

```env
OWNER_IDS=123456789012345678,987654321098765432
```

Comma-separated list of Discord user IDs that can use every command regardless of role.

---

## 3. Register the new slash commands

Run your deploy script (same as you do now):

```bash
node src/deploy-commands.js
```

---

## 4. Commands summary

### Player commands (everyone)
| Command | What it does |
|---------|--------------|
| `/checkvalor` | Check your own valor balance |
| `/vshopcheck` | See what's in the shop |
| `/purchase item` | Buy something from the shop |
| `/checkinv` | Check your own inventory |

### LT commands (Loreteam role or bot owners)
| Command | What it does |
|---------|--------------|
| `/commend @user amount` | Add valor to a user |
| `/addvalor @user amount` | Same as /commend |
| `/checkvalor @user` | Check any user's valor |
| `/vshopadd name price` | Add item to shop |
| `/vshopcheck` | See what's in the shop |
| `/vshopremove name` | Remove item from shop |
| `/vshopinflate name amount` | Raise an item's price |
| `/vshopdeflate name amount` | Lower an item's price |
| `/viewinv @user` | See any user's inventory |
| `/logvalor` | Last 24h of valor changes |

### Owner-only
| Command | What it does |
|---------|--------------|
| `/loreteam @role` | Set which role gets LT perms |

---

## 5. How it works

- **Valor** is stored per-user per-guild in MongoDB.
- **Shop items** are per-guild. LT sets prices, players buy with valor.
- **Inventory** is per-user per-guild. Purchases auto-add items there.
- **Logs** record every ADD and SPEND — `/logvalor` shows the last 24h.
- **Permissions** check `OWNER_IDS` env var first, then the role set by `/loreteam`.
- **No extra hosting** — 5 small MongoDB collections, no polling or background jobs.
